## **Assets Folder**
The usage of this folder is to store images required for this project's readme and other stuff.