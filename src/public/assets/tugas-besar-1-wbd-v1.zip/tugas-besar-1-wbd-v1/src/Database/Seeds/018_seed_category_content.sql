INSERT INTO category_content (
    category_id,
    content_id
) VALUES (
    1,
    1
)