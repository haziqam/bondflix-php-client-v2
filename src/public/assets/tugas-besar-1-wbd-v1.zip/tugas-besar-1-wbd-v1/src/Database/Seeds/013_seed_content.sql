INSERT INTO content (
    title, 
    description, 
    release_date, 
    content_file_path, 
    thumbnail_file_path
) VALUES (
    'up',
    'rumah terbang',
    '2023-10-02',
    '/uploads/content/up.mp4',
    '/uploads/thumbnail/up.jpeg'
);