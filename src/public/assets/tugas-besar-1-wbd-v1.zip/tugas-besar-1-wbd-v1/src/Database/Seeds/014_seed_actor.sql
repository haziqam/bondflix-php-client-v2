INSERT INTO actor (
    first_name,
    last_name, 
    birth_date, 
    gender
) VALUES (
    'siapa',
    'aku',
    '2023-10-02',
    'male'
);