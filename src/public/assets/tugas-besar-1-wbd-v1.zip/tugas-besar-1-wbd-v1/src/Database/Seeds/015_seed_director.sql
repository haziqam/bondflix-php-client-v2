INSERT INTO director (
    first_name,
    last_name
) VALUES (
    'foo',
    'bar'
);