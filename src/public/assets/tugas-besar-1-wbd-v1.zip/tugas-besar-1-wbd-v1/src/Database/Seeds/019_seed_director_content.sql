INSERT INTO director_content (
    actor_id,
    director_id
) VALUES (
    1,
    1
)