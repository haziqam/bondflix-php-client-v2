INSERT INTO actor_content (
    actor_id,
    content_id
) VALUES (
    1,
    1
)