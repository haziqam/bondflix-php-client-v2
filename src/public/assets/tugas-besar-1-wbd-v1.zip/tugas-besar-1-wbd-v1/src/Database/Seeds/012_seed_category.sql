INSERT INTO category (category_name)
VALUES
    ('Adventure'),
    ('Romance'),
    ('Mystery'),
    ('Fantasy'),
    ('Thriller');
