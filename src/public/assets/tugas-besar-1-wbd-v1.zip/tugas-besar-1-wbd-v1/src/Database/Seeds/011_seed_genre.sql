INSERT INTO genre (genre_name)
VALUES
    ('Action'),
    ('Drama'),
    ('Comedy'),
    ('Science Fiction'),
    ('Horror');