INSERT INTO genre_content (
    content_id,
    genre_id
) VALUES (
    1,
    1
)