<?php

session_start();
require_once 'bootstrap.php';
require_once 'routes.php';