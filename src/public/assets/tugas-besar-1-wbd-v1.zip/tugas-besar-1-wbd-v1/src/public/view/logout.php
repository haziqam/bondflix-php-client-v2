<?php

echo "Muah";

exit;

