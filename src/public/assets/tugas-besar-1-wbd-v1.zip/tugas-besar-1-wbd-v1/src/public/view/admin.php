<?php
//    $pageTitle = 'Admin Dashboard';
//    include BASE_PATH . "/public/templates/header.php";
//    $adminSidebarTemplate = BASE_PATH . "/public/templates/admin-sidebar.php";
//    $username = $_SESSION['username'];
    href('/admin/users')
?>

<!--<link rel="stylesheet" href="/public/css/admin-page.css">-->
<?php //include $adminSidebarTemplate ?>
<!---->
<!--<body>-->
<!--    <div class="content">-->
<!--        <p>Welcome to Admin Page, --><?php //echo $username ?><!--!</p>-->
<!--    </div>-->
<!--</body>-->
