<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="/public/favicon.ico" type="image/x-icon" />
    <title>Bondflix - <?php echo $pageTitle; ?></title>
    <script src="/public/js/http_client.js"></script>
    <script src="/public/js/helper.js"></script>
</head>

<!--<script>-->
<!--    setTimeout(function() {-->
<!--        document.getElementById('loading-overlay').style.display = 'none';-->
<!--    }, 2000);-->
<!--</script>-->