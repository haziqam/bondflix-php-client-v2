docker build -t tubes-1:latest -f dockerfiles/Dockerfile.php-apache .
